# LinkedIn Learning Python course by Joe Marini
# Example file for working with Exceptions
#

# Errors can happen in programs, and we need a clean way to handle them
# This code will cause an error because you can't divide by zero:
# x = 10/0

# Exceptions provide a way of catching errors and then handling them in 
# a separate section of the code to group them together
# try:
#   x = 10/0
# except:
#   print("You can't do that!")

# You can also catch specific exceptions
try:
  answer = input("What should I divide 10 by?")
  num = int(answer)
  print(10/num)
except ZeroDivisionError as e:
  print("You can't divide by zero, dummy!")
except ValueError as e:
  print("That's not a number, idiot!")
  print(e)
finally: # The finally section will always execute regardless if any error occurs
  print("Finally always runs")
